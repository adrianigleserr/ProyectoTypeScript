/**
 * IMPORTACIÓN DE LIBRERÍAS
 * - reflect-metadata: Necesario para que funcionen los decoradores de TypeORM.
 * - express: Framework para crear el servidor web y la API REST.
 * - typeorm: ORM (Object Relational Mapper) para gestionar la base de datos usando objetos.
 * - cors: Middleware para permitir peticiones desde el navegador.
 */
import "reflect-metadata";
import express from "express";
import { DataSource, Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from "typeorm";
import cors from "cors";
import path from "path";

// ==========================================
// ZONA DE MODELADO DE DATOS (OOP)
// Definición de las Entidades que representan las tablas en la BD.
// ==========================================

/**
 * Entidad Socio: Representa a los usuarios de la biblioteca.
 */
@Entity()
export class Socio {
    @PrimaryGeneratedColumn() // ID autoincremental
    id!: number;

    @Column()
    nombre!: string;

    @Column()
    dni!: string;

    @Column()
    telefono!: string;
}

/**
 * Entidad Libro: Representa el catálogo bibliográfico.
 */
@Entity()
export class Libro {
    @PrimaryGeneratedColumn()
    id!: number;

    @Column()
    titulo!: string;

    @Column()
    genero!: string;

    // Estado del libro. True = Disponible para prestar.
    @Column({ default: true })
    disponible!: boolean; 
}

/**
 * Entidad Prestamo: Tabla intermedia que relaciona Socios y Libros.
 * Registra cuándo se prestó y cuándo se devuelve.
 */
@Entity()
export class Prestamo {
    @PrimaryGeneratedColumn()
    id!: number;
    
    @CreateDateColumn() // Se rellena sola con la fecha actual al crear
    fechaInicio!: Date;

    @Column({ nullable: true }) // Puede ser null si aún no se ha devuelto
    fechaDevolucion!: Date; 

    // RELACIONES (Foreign Keys)
    @ManyToOne(() => Socio) // Muchos préstamos pueden pertenecer a un Socio
    socio!: Socio;

    @ManyToOne(() => Libro) // Muchos préstamos históricos pueden referirse a un Libro
    libro!: Libro;
}

// ==========================================
// CONFIGURACIÓN DE LA BASE DE DATOS
// ==========================================
const db = new DataSource({
    type: "sqlite",             // Motor de base de datos ligero (archivo local)
    database: "biblioteca.db",  // Nombre del archivo
    synchronize: true,          // ¡IMPORTANTE! Crea las tablas automáticamente según las Entidades
    entities: [Socio, Libro, Prestamo], // Lista de clases a utilizar
});

// ==========================================
// CONFIGURACIÓN DEL SERVIDOR EXPRESS
// ==========================================
const app = express();
app.use(cors());           // Permite conexiones externas
app.use(express.json());   // Permite leer JSON en el cuerpo de las peticiones (req.body)

// Middleware para servir los archivos del Frontend (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, '../public')));

// ==========================================
// RUTAS DE LA API (CONTROLADORES)
// ==========================================

// --- GESTIÓN DE SOCIOS ---

// Obtener todos los socios
app.get("/api/socios", async (req, res) => {
    const socios = await db.getRepository(Socio).find();
    res.json(socios);
});

// Crear un nuevo socio
app.post("/api/socios", async (req, res) => {
    const nuevoSocio = await db.getRepository(Socio).save(req.body);
    res.json(nuevoSocio);
});

// Modificar un socio existente (Requisito: Modificación de datos)
app.put("/api/socios/:id", async (req, res) => {
    const { id } = req.params;
    await db.getRepository(Socio).update(id, req.body);
    res.json({ message: "Socio actualizado correctamente" });
});

// --- GESTIÓN DE LIBROS ---

// Obtener libros (permite filtrar por género o disponibilidad)
app.get("/api/libros", async (req, res) => {
    const { genero } = req.query; // Leemos parámetros de la URL ?genero=Terror
    const where: any = {};
    
    if (genero) where.genero = genero; // Filtro dinámico
    
    const libros = await db.getRepository(Libro).find({ where });
    res.json(libros);
});

// Crear un nuevo libro
app.post("/api/libros", async (req, res) => {
    const nuevoLibro = await db.getRepository(Libro).save(req.body);
    res.json(nuevoLibro);
});

// --- GESTIÓN DE PRÉSTAMOS (LÓGICA DE NEGOCIO) ---

// Listar préstamos incluyendo los datos relacionados del Libro y el Socio
app.get("/api/prestamos", async (req, res) => {
    const prestamos = await db.getRepository(Prestamo).find({ 
        relations: ["libro", "socio"] // Hacemos JOIN con las otras tablas
    });
    res.json(prestamos);
});

// Crear un préstamo (Transacción compleja)
app.post("/api/prestamos", async (req, res) => {
    const { socioId, libroId } = req.body;
    const libroRepo = db.getRepository(Libro);
    
    // 1. Validar disponibilidad del libro
    const libro = await libroRepo.findOneBy({ id: libroId });
    if (!libro || !libro.disponible) {
        return res.status(400).json({ error: "El libro no existe o ya está prestado" });
    }

    // 2. Crear el registro del préstamo
    const prestamo = new Prestamo();
    prestamo.socio = { id: socioId } as Socio; // Asignamos por ID
    prestamo.libro = libro;
    await db.getRepository(Prestamo).save(prestamo);

    // 3. Actualizar estado del libro a "No disponible"
    libro.disponible = false;
    await libroRepo.save(libro);

    res.json(prestamo);
});

// Devolver un libro
app.post("/api/prestamos/:id/devolver", async (req, res) => {
    const prestamoRepo = db.getRepository(Prestamo);
    
    // Buscamos el préstamo y su libro relacionado
    const prestamo = await prestamoRepo.findOne({ 
        where: { id: parseInt(req.params.id) }, 
        relations: ["libro"] 
    });
    
    if (!prestamo || prestamo.fechaDevolucion) {
        return res.status(400).json({ error: "Préstamo no encontrado o ya devuelto" });
    }

    // 1. Marcar fecha de devolución
    prestamo.fechaDevolucion = new Date();
    await prestamoRepo.save(prestamo);

    // 2. Liberar el libro (Vuelve a estar disponible)
    const libroRepo = db.getRepository(Libro);
    prestamo.libro.disponible = true;
    await libroRepo.save(prestamo.libro);

    res.json({ message: "Libro devuelto con éxito" });
});

// ==========================================
// INICIALIZACIÓN
// ==========================================
db.initialize().then(() => {
    console.log("✅ Base de datos conectada con éxito");
    app.listen(3000, () => console.log("🚀 Servidor escuchando en http://localhost:3000"));
}).catch(error => console.log("Error al iniciar la BD:", error));